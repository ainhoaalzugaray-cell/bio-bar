BIO BAR — ARCHIVOS PARA GITHUB

Incluye:
- index.html: Inicio.
- carta.html: Nuestra carta.
- contacto.html: Contacto y formulario de reserva.
- styles.css: diseño responsive para ordenador y móvil.
- script.js: menú móvil y preparación del correo del formulario.

SUBIR A GITHUB:
1. Entra en https://github.com.
2. Pulsa + > New repository.
3. Nombre: bio-bar-web. Selecciona Public y crea el repositorio.
4. Pulsa Add file > Upload files.
5. Descomprime este ZIP y arrastra TODOS los archivos a GitHub.
6. Pulsa Commit changes.

IMPORTANTE:
Los archivos HTML, CSS y JS deben quedar en la raíz del repositorio.
Las imágenes y tipografías se cargan desde Unsplash y Google Fonts, por lo que requieren Internet.
El formulario prepara un correo en la aplicación de email del visitante; no guarda ni envía datos a un servidor.
BIO BAR, ubicación, email, horario, platos y precios son ficticios y se han creado para una actividad académica.
Después, importa el repositorio desde Vercel para publicar la web con HTTPS.
